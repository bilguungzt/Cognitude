-- This script will completely reset your Alembic migration history.
-- Run this in the Supabase SQL Editor to resolve history conflicts.
DROP TABLE IF EXISTS alembic_version;