import React, { useEffect, useState } from "react";
import { motion } from "framer-motion";
import axios from "axios";
import Layout from "../components/Layout";
import { api } from "../services";
import { DollarSign, Zap, Clock } from "lucide-react";
import HeroStats from "../components/Autopilot/HeroStats";
import StatCard from "../components/Autopilot/StatCard";
import ClassificationChart from "../components/Autopilot/ClassificationChart";
import ModelRoutingChart from "../components/Autopilot/ModelRoutingChart";
import Skeleton from "../components/Skeleton";
import type { AutopilotDashboardData } from "../types/api";

const AutopilotPage: React.FC = () => {
  const [data, setData] = useState<AutopilotDashboardData | null>(null);
  const [loading, setLoading] = useState<boolean>(true);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    const fetchData = async () => {
      setLoading(true);
      setError(null);
      try {
        const dashboardData = await api.getAutopilotDashboardData();
        setData(dashboardData);
      } catch (err) {
        if (axios.isAxiosError(err) && err.response?.status === 404) {
          const zeroState: AutopilotDashboardData = {
            heroStats: {
              couldHaveSpent: 0,
              actuallySpent: 0,
              savings: 0,
            },
            keyMetrics: [
              {
                title: "Optimization Rate",
                value: "0%",
                comparison: "No data",
              },
              {
                title: "Avg. Response Time",
                value: "0ms",
                comparison: "No data",
              },
              {
                title: "Total Requests",
                value: "0",
                comparison: "No data",
              },
            ],
            classificationBreakdown: {
              labels: [],
              datasets: [{ data: [], backgroundColor: [] }],
            },
            modelRouting: {
              nodes: [],
              links: [],
            },
            logs: [],
          };
          setData(zeroState);
        } else {
          setError(api.handleError(err));
        }
      } finally {
        setLoading(false);
      }
    };

    fetchData();
  }, []);

  const containerVariants = {
    hidden: { opacity: 0 },
    visible: {
      opacity: 1,
      transition: {
        staggerChildren: 0.1,
      },
    },
  };

  const itemVariants = {
    hidden: { y: 20, opacity: 0 },
    visible: {
      y: 0,
      opacity: 1,
      transition: {
        type: "spring" as const,
        stiffness: 100,
      },
    },
  };

  const renderSkeletons = () => (
    <div className="space-y-8">
      <Skeleton className="h-48 w-full" />
      <div className="grid gap-4 md:grid-cols-3">
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
        <Skeleton className="h-32 w-full" />
      </div>
      <div className="grid gap-4 md:grid-cols-2">
        <Skeleton className="h-96 w-full" />
        <Skeleton className="h-96 w-full" />
      </div>
      <Skeleton className="h-64 w-full" />
    </div>
  );

  return (
    <Layout title="Autopilot Dashboard">
      {loading ? (
        renderSkeletons()
      ) : error ? (
        <div className="text-center text-red-500">
          <p>Error loading dashboard data:</p>
          <p>{error}</p>
        </div>
      ) : data ? (
        <motion.div
          variants={containerVariants}
          initial="hidden"
          animate="visible"
          className="space-y-8"
        >
          {/* Hero Section */}
          <motion.div variants={itemVariants}>
            <HeroStats stats={data.heroStats} />
          </motion.div>

          {/* Key Metrics */}
          <motion.div
            variants={itemVariants}
            className="grid gap-4 sm:grid-cols-1 md:grid-cols-2 lg:grid-cols-3"
          >
            {data.keyMetrics.map((metric, index) => {
              const icons = {
                "Optimization Rate": Zap,
                "Avg. Response Time": Clock,
                "Total Requests": DollarSign,
              };
              const Icon =
                icons[metric.title as keyof typeof icons] || DollarSign;
              return (
                <StatCard
                  key={index}
                  icon={Icon}
                  title={metric.title}
                  value={metric.value}
                  comparisonText={metric.comparison}
                />
              );
            })}
          </motion.div>

          {/* Charts */}
          <motion.div
            variants={itemVariants}
            className="grid gap-4 sm:grid-cols-1 md:grid-cols-1 lg:grid-cols-2"
          >
            <ClassificationChart
              data={data.classificationBreakdown.labels.reduce(
                (acc, label, index) => {
                  acc[label] =
                    data.classificationBreakdown.datasets[0].data[index];
                  return acc;
                },
                {} as { [key: string]: number }
              )}
            />
            <ModelRoutingChart data={data.logs} />
          </motion.div>

          {/* Real-time Logs */}
          <motion.div variants={itemVariants}>
            {/* Using light-mode-friendly styles for the container */}
            <div className="bg-white/50 backdrop-blur-lg rounded-xl shadow-lg p-6 border border-gray-200">
              <h2 className="text-xl font-bold text-gray-800 mb-4">
                Real-time Logs
              </h2>
              <div className="overflow-x-auto">
                {/* Mobile View */}
                <div className="sm:hidden space-y-3">
                  {data.logs.map((log, index) => (
                    <div key={index} className="p-4 bg-white rounded-lg shadow-sm border border-gray-100">
                      <div className="flex items-center justify-between mb-2">
                        <div className="text-sm font-medium text-gray-900">{new Date(log.timestamp).toLocaleString()}</div>
                        <div className="text-sm font-semibold text-green-600">${log.cost_saved.toFixed(4)}</div>
                      </div>
                      <div className="grid grid-cols-2 gap-2 text-xs text-gray-600">
                        <div><span className="font-medium">Original:</span> {log.original_model}</div>
                        <div><span className="font-medium">Selected:</span> {log.selected_model}</div>
                        <div><span className="font-medium">Speed:</span> {log.speed_improvement}ms</div>
                        <div className="col-span-2"><span className="font-medium">Reason:</span> {log.reason}</div>
                      </div>
                    </div>
                  ))}
                </div>
                {/* Desktop View */}
                <div className="hidden sm:block">
                  <table className="min-w-full">
                    {/* --- HEADER --- */}
                    <thead>
                      <tr>
                        <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">
                          Timestamp
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">
                          Original Model
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">
                          Selected Model
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">
                          Reason
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">
                          Cost Saved
                        </th>
                        <th className="px-6 py-3 text-left text-xs font-bold text-gray-500 uppercase tracking-wider">
                          Speed Improv.
                        </th>
                      </tr>
                    </thead>

                    {/* --- BODY --- */}
                    <tbody>
                      {data.logs.map((log, index) => (
                        <tr
                          key={index}
                          className="border-b border-gray-200 hover:bg-gray-50"
                        >
                          {/* Timestamp */}
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-900">
                            {new Date(log.timestamp).toLocaleString()}
                          </td>

                          {/* Models (Slightly lighter text) */}
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 font-mono">
                            {log.original_model}
                          </td>
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-gray-600 font-mono">
                            {log.selected_model}
                          </td>

                          {/* Reason (Allows wrapping) */}
                          <td className="px-6 py-4 text-sm text-gray-900">
                            {log.reason}
                          </td>

                          {/* Cost Saved */}
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-green-600 font-semibold">
                            ${log.cost_saved.toFixed(4)}
                          </td>

                          {/* Speed Improv. */}
                          <td className="px-6 py-4 whitespace-nowrap text-sm text-blue-600 font-semibold">
                            {log.speed_improvement}ms
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>
              </div>
            </div>
          </motion.div>
        </motion.div>
      ) : null}
    </Layout>
  );
};

export default AutopilotPage;
